//
// Created by henri on 21.10.24.
//

#ifndef IDOL_UUID_H
#define IDOL_UUID_H

#include <string>
#include <random>
#include <sstream>

namespace idol {
    std::string generate_uuid_v4();
}

#endif //IDOL_UUID_H
