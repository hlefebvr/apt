//
// Created by henri on 27/01/23.
//

#ifndef IDOL_ENV_H
#define IDOL_ENV_H

#include <list>
#include <thread>

#include "idol/mixed-integer/modeling/variables/Var.h"
#include "idol/mixed-integer/modeling/variables/VarVersion.h"
#include "idol/mixed-integer/modeling/variables/TempVar.h"
#include "Versions.h"
#include "ObjectId.h"
#include "idol/mixed-integer/modeling/annotations/impl_Annotation.h"
#include "idol/mixed-integer/modeling/constraints/QCtrVersion.h"
#include "idol/mixed-integer/modeling/constraints/QCtr.h"
#include "idol/mixed-integer/modeling/constraints/TempQCtr.h"
#include "idol/mixed-integer/modeling/constraints/SOSCtrVersion.h"
#include "idol/mixed-integer/modeling/constraints/SOSCtr.h"

namespace idol {

    class Model;

    namespace impl {
        class Env;

        template<unsigned int Start>
        class IdProvider;
    }

}

template<unsigned int Start>
class idol::impl::IdProvider {
    unsigned int m_max_id = Start;
    std::list<unsigned int> m_free_ids;
public:
    void free(unsigned int t_id) { m_free_ids.emplace_back(t_id); }

    unsigned int create() {
        if (m_free_ids.empty()) {
            return m_max_id++;
        }

        auto result = m_free_ids.back();
        m_free_ids.pop_back();
        return result;
    }
};

class idol::impl::Env {
    // Tolerances
    double m_tol_mip_relative_gap = 1e-4;
    double m_tol_mip_absolute_gap = 1e-5;
    double m_tol_integer = 1e-5;
    double m_tol_feasibility = 1e-6;
    double m_tol_optimality = 1e-6;

    // Parameters
    bool m_param_logs = false;
    bool m_param_presolve = true;
    double m_param_time_limit = std::numeric_limits<double>::max();
    unsigned int m_param_thread_limit;
    double m_param_best_bound_stop = Inf;
    double m_param_best_obj_stop = -Inf;
    unsigned int m_param_iteration_limit = std::numeric_limits<unsigned int>::max();
    bool m_param_infeasible_or_unbounded_info = false;

    // Objects
    unsigned int m_max_object_id = 0;

    IdProvider<1> m_model_ids;
    IdProvider<0> m_annotation_ids;

    std::list<Versions<VarVersion>> m_variables; /// Every version of each variable in the environment is stored here
    std::list<Versions<CtrVersion>> m_constraints; /// Every version of each constraint in the environment is stored here
    std::list<Versions<QCtrVersion>> m_qconstraints; /// Every version of each quadratic constraint in the environment is stored here
    std::list<Versions<SOSCtrVersion>> m_sosconstraints; /// Every version of each sos constraint in the environment is stored here

    template<class T, class VersionT, class ...ArgsT>
    ObjectId<VersionT> create(std::string t_name, const std::string& t_default_name, std::list<Versions<VersionT>>& t_container, ArgsT&& ...t_args) {
        const unsigned int id = m_max_object_id++;
        std::string name = t_name.empty() ? t_default_name + '_' + std::to_string(id) : std::move(t_name);
        t_container.emplace_front(-1, std::forward<ArgsT>(t_args)...);
        return { t_container.begin(), id, std::move(name) };
    }
protected:
    unsigned int create_model_id() { return m_model_ids.create(); }

    void free_model_id(const ::idol::Model& t_model);

    unsigned int create_annotation_id() { return m_annotation_ids.create(); }

    void free_annotation_id(const impl::Annotation& t_annotation);

    template<class T, class ...ArgsT>
    void create_version(const Model& t_model, const T& t_object, unsigned int t_index, ArgsT&& ...t_args) {
        t_object.create_version(t_model, t_index, std::forward<ArgsT&&>(t_args)...);
    }

    template<class T>
    void remove_version(const Model& t_model, const T& t_object) {
        t_object.remove_version(t_model);
    }

    template<class T>
    bool has_version(const Model& t_model, const T& t_object) const {
        return t_object.is_in(t_model);
    }

    template<class T>
    const auto& version(const Model& t_model, const T& t_object) const {
        return t_object.versions().get(t_model);
    }

    template<class T>
    auto& version(const Model& t_model, const T& t_object) {
        return const_cast<T&>(t_object).versions().get(t_model);
    }

    ObjectId<VarVersion> create_var(std::string t_name, TempVar&& t_temp_var) {
        return create<Var>(std::move(t_name), "x", m_variables, std::move(t_temp_var));
    }

    ObjectId<CtrVersion> create_ctr(std::string t_name, TempCtr&& t_temp_ctr) {
        return create<Ctr>(std::move(t_name), "c", m_constraints, std::move(t_temp_ctr));
    }

    ObjectId<QCtrVersion> create_qctr(std::string t_name, TempQCtr&& t_temp_ctr) {
        return create<QCtr>(std::move(t_name), "c", m_qconstraints, std::move(t_temp_ctr));
    }

    ObjectId<SOSCtrVersion> create_sosctr(std::string t_name, bool t_is_sos1, std::vector<Var>&& t_vars, std::vector<double>&& t_weights) {
        return create<SOSCtr>(std::move(t_name), "sos", m_sosconstraints, t_is_sos1, std::move(t_vars), std::move(t_weights));
    }

public:
    Env() : m_param_thread_limit(std::max<unsigned int>(std::thread::hardware_concurrency(), 1)) {}

    Env(const Env&) = delete;
    Env(Env&&) noexcept = delete;

    Env& operator=(const Env&) = delete;
    Env& operator=(Env&&) noexcept = delete;

    /**
     * Returns the default version of an optimization object.
     * @tparam T The type of object queried.
     * @param t_object The object.
     * @returnthe The default version of an optimization object.
     */
    template<class T>
    const auto& operator[](const T& t_object) const {
        return t_object.versions().get_default();
    }

    // Tolerances
    [[nodiscard]] double get_tol_mip_relative_gap() const { return m_tol_mip_relative_gap; }
    [[nodiscard]] double get_tol_mip_absolute_gap() const { return m_tol_mip_absolute_gap; }
    [[nodiscard]] double get_tol_integer() const { return m_tol_integer; }
    [[nodiscard]] double get_tol_feasibility() const { return m_tol_feasibility; }
    [[nodiscard]] double get_tol_optimality() const { return m_tol_optimality; }

    void set_tol_mip_relative_gap(double t_value) { m_tol_mip_relative_gap = t_value; }
    void set_tol_mip_absolute_gap(double t_value) { m_tol_mip_absolute_gap = t_value; }
    void set_tol_integer(double t_value) { m_tol_integer = t_value; }
    void set_tol_feasibility(double t_value) { m_tol_feasibility = t_value; }
    void set_tol_optimality(double t_value) { m_tol_optimality = t_value; }

    // Parameters
    [[nodiscard]] bool get_param_logs() const { return m_param_logs; }
    [[nodiscard]] bool get_param_presolve() const { return m_param_presolve; }
    [[nodiscard]] double get_param_time_limit() const { return m_param_time_limit; }
    [[nodiscard]] unsigned int get_param_thread_limit() const { return m_param_thread_limit; }
    [[nodiscard]] double get_param_best_bound_stop() const { return m_param_best_bound_stop; }
    [[nodiscard]] double get_param_best_obj_stop() const { return m_param_best_obj_stop; }
    [[nodiscard]] unsigned int get_param_iteration_limit() const { return m_param_iteration_limit; }
    [[nodiscard]] bool get_param_infeasible_or_unbounded_info() const { return m_param_infeasible_or_unbounded_info; }

    void set_param_logs(bool t_param_logs) { m_param_logs = t_param_logs; }
    void set_param_presolve(bool t_param_press) { m_param_presolve = t_param_press; }
    void set_param_time_limit(double t_param_time) { m_param_time_limit = t_param_time; }
    void set_param_thread_limit(unsigned int t_param_thread_limit) { m_param_thread_limit = t_param_thread_limit; }
    void set_param_best_bound_stop(double t_best_bound_stop) { m_param_best_bound_stop = t_best_bound_stop; }
    void set_param_best_obj_stop(double t_best_obj_stop) { m_param_best_obj_stop = t_best_obj_stop; }
    void set_param_iteration_limit(unsigned int t_iteration_limit) { m_param_iteration_limit = t_iteration_limit; }
    void set_param_infeasible_or_unbounded_info(bool t_param_infeasible_or_unbounded_info) { m_param_best_bound_stop = t_param_infeasible_or_unbounded_info; }
};

/**
 * Environment class.
 *
 * This class stores and manages every optimization objects and
 * annotations in idol.
 *
 * Essentially, it is the environment that controls the death and lives of such objects. It is through the environment
 * that idol manages the different versions each optimization object may have during the execution of your program.
 *
 * **Important**: If an optimization environment is destroyed, all of its objects are also destroyed. Trying to access them
 * will lead to undefined behavior and, eventually, segmentation fault.
 *
 *
 * Typically, only one environment should be used by your code, though it is possible to instantiate many environment (not advised).
 *
 * Environments are objects of the Env class and can be created as follows.
 *
 * ```cpp
 * Env env; // Creates a new optimization environment.
 * ```
 */
class idol::Env : public impl::Env {
public:
    /**
     * Constructor.
     *
     * Creates a new optimization environment.
     */
    Env() = default;

    friend class Model;
    friend class Var;
    friend class Ctr;
    friend class QCtr;
    friend class SOSCtr;
    friend class impl::Annotation;
};


#endif //IDOL_ENV_H
