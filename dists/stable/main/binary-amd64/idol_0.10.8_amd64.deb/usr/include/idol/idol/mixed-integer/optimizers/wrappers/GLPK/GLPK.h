//
// Created by henri on 23/03/23.
//

#ifndef IDOL_GLPK_H
#define IDOL_GLPK_H

#include "idol/general/optimizers/OptimizerFactory.h"
#include "idol/mixed-integer/modeling/objects/Env.h"

namespace idol {
    class GLPK;
}

class idol::GLPK : public OptimizerFactoryWithDefaultParameters<GLPK> {
    std::optional<bool> m_continuous_relaxation;

    explicit GLPK(bool t_continuous_relaxation) : m_continuous_relaxation(t_continuous_relaxation) {}
protected:
    Optimizer *create(const Model &t_model) const override;
public:
    GLPK() = default;

    GLPK(const GLPK&) = default;
    GLPK(GLPK&&) noexcept = default;

    GLPK& operator=(const GLPK&) = delete;
    GLPK& operator=(GLPK&&) noexcept = delete;

    static GLPK ContinuousRelaxation();

    [[nodiscard]] GLPK *clone() const override;

    GLPK& with_continuous_relaxation_only(bool t_value);

    static Model read_from_file(Env& t_env, const std::string& t_filename);
};


#endif //IDOL_GLPK_H
